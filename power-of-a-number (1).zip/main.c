/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************///c program to find power of any number using for loop
#include <stdio.h>

int main()
{
    int base,exponent;
    long power=1;
    int i=1;
    printf("enter base:");
  scanf("%d",&base);
  printf("enter exponent:");
  scanf("%d",&exponent);
  for(i=1;i<=exponent;i++) {
      power=power*base;
  }
  printf("%d^%d=%d",base,exponent,power);
  return 0;
}
  



