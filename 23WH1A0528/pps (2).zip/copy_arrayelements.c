//this is to copy elements of one array into another array
#include<
