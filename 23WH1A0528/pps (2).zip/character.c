#include <stdio.h>
int main() {
char ch;
printf("enter any character");
scanf("%c",&ch);
printf("%d",ch);
return 0;
}
