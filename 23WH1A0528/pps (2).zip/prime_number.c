//to find out whether given number is prime or not
#include<stdio.h>
int main() {
int num,count=0;
printf("enter a number");
scanf("%d",&num);
for(int i=1; i<=num; i++){
	if(num%i == 0)
		 count++;
}
if (count==2)
	printf("the number is prime number");
else
	printf("the number is not prime number");
return 0;
}
