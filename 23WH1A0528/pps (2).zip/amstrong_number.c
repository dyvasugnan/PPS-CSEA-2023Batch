//to find perfect number
#include <stdio.h>
int main() {
int num,i=1,sum=0;
printf("enter a number");
scanf("%d",&num);
while(i<=num){
	if(num%i == 0)
	sum = sum+i;
	i++;
      }
if(sum==2*num)
	printf("it is a perfect number");

else
	printf("it is not a perfect number");
return 0;
}
